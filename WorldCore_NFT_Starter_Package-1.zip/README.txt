WORLDCORE GENESIS NFT PACKAGE

Files:
- WorldCoreGenesisNFT.sol : ERC-721 NFT contract (OpenZeppelin Contracts 5.x, Solidity 0.8.20+)
- 1.json                  : OpenSea-compatible metadata template

BEFORE MINTING:
1. Upload the final WorldCore logo image PNG to IPFS using a pinning service.
2. Replace REPLACE_WITH_YOUR_IMAGE_CID in 1.json with the image's real IPFS CID.
   Example: "image": "ipfs://bafy...your-real-image-cid..."
3. Upload the completed 1.json to IPFS.
4. Copy the resulting metadata URI, e.g. ipfs://bafy.../1.json
5. Compile and deploy the contract in Remix using Solidity 0.8.20 or newer and OpenZeppelin Contracts 5.x.
   Constructor argument: your own wallet address (initialOwner).
6. After deployment, call mint(your_wallet_address, "ipfs://YOUR_METADATA_CID/1.json").

IMPORTANT:
- This package does not upload files to IPFS and does not deploy the contract.
- Do not use a CID placeholder; the image and metadata must be uploaded first.
- Test on a testnet first. Deployment and minting require network gas fees.
- Never share your wallet seed phrase or private key.
- This is an NFT contract template, not an audit or a guarantee of marketplace listing.
