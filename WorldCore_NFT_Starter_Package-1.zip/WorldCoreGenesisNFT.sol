// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

/**
 * WorldCore Genesis NFT
 * Owner-controlled minting; each token has its own metadata URI.
 * Test on a testnet before mainnet deployment.
 */
contract WorldCoreGenesisNFT is ERC721URIStorage, Ownable {
    uint256 public constant MAX_SUPPLY = 1000;
    uint256 private _nextTokenId = 1;

    constructor(address initialOwner)
        ERC721("WorldCore Genesis NFT", "WCORENFT")
        Ownable(initialOwner)
    {}

    function mint(address to, string calldata metadataURI)
        external
        onlyOwner
        returns (uint256 tokenId)
    {
        require(to != address(0), "Invalid recipient");
        require(_nextTokenId <= MAX_SUPPLY, "Max supply reached");
        require(bytes(metadataURI).length > 0, "Metadata URI required");

        tokenId = _nextTokenId;
        _nextTokenId++;
        _safeMint(to, tokenId);
        _setTokenURI(tokenId, metadataURI);
    }
}
